'use strict';

module.exports = function (id, name, preview_image, image, order) {
  this.id = id;
  this.name = name;
  this.preview_image = preview_image;
  this.image = image;
  this.order = order;
}
